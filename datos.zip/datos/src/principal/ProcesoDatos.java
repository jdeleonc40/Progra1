
package principal;

import java.util.ArrayList;

public class ProcesoDatos {
    private ArrayList<Object> a = new ArrayList<Object>();
    // Constructor para Array
    public ProcesoDatos(){
        
    }
    public ProcesoDatos(ArrayList<Object> a){
        this.a = a;
    }
    // Crea registro en archivo plano delimitado por comas
    public void crearRegistro(DatosP p){
        this.a.add(p);
    }
    //modifica registro
    public void modifcarRegistro(int i, DatosP p){
    this.a.set(i, p);        
    }
    //Eliminar registros
    public void eliminarRegistro (int i){
        this.a.remove(i);
    }
    // Recorrido e insertar datos 
    public DatosP obtenerRegistro(int i){
        return (DatosP)a.get(i);
    }
    //Determina la cantidad de registros encontrados
    public int cantidadRegistros(){
        return this.a.size();
    }
    // Buscador
    public int buscarTelefono (int telefono){
    for(int i=0; i<cantidadRegistros();i++){
    if(telefono== obtenerRegistro(i).getCodigo())return i;
   }  
    return -1;
    
}
}
